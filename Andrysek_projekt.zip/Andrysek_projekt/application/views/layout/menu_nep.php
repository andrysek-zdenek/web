<ul class="nav navbar-nav">
<?php
echo '<li>'. anchor('admin/login', 'Login');
echo '<li>'. anchor('register', 'Registrace');
echo '<li>'. anchor('tabulkaN/nazev/acs', 'Tabulka');
?>
</ul>
<ul class="nav navbar-nav navbar-right navbar-text">
<?php
echo '<li>'. anchor('admin/login', 'Login');
?> </ul>
